package com.example.stompcovidrumors

data class User (val email: String="")